import typer

app = typer.Typer()


@app.command()
def hello() -> None:
    """Minimal health check command."""
    print("ShapePlay CLI is ready!")


if __name__ == "__main__":
    app()
